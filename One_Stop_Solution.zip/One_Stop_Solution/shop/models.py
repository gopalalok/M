from django.db import models
from django.utils import timezone
class Product(models.Model):
    name = models.CharField(max_length=100)
    price = models.IntegerField()

    @staticmethod
    def get_all_product():
        return Product.objects.all()

    @staticmethod
    def get_products_by_id(id):
        return Product.objects.filter(id = id)

    def __str__(self):
        return self.name

class State(models.Model):
    name = models.CharField(max_length=100)

    @staticmethod
    def get_all_state():
        return State.objects.all()

    @staticmethod
    def get_state_by_id(id):
        return State.objects.filter(id = id)

    def __str__(self):
        return self.name


class Customer(models.Model):
    transactionid = models.CharField(max_length= 500,default='')
    fullname = models.CharField(max_length=100, default='', blank=True)
    item = models.ForeignKey(Product, on_delete = models.CASCADE)
    quantity = models.IntegerField(default=1)
    amount = models.CharField(max_length=50, default='', blank=True)
    mobilenumber = models.CharField(max_length=50, default='', blank=True)
    address = models.CharField(max_length=100, default='', blank=True)
    landmark = models.CharField(max_length=100, default='', blank=True)
    city = models.CharField(max_length=50, default='', blank=True)
    state = models.ForeignKey(State, on_delete = models.CASCADE)
    pincode = models.CharField(max_length=20, default='', blank=True)
    dtime = models.DateTimeField(default=timezone.now)

    @staticmethod
    def get_customer_order(transactionid):
        return Customer.objects.get(transactionid = transactionid)

    @staticmethod
    def get_all_customer():
        queryset = Customer.objects.all().order_by('-dtime')
        return queryset

    