
from django.contrib import admin
from django.urls import path,include
from .views.index import IndexView
from .views.recive import ReciveView
from .views.order import OrderView
from .views.customer_order import Customer_OrderView

urlpatterns = [
    path('', IndexView.as_view(), name='home'),   
    path('recive/', ReciveView.as_view(), name='recive'),
    path('order_view/', OrderView.as_view(), name='all_order_view'),
    path('view_order/<int:id>', Customer_OrderView.as_view(), name='view_order'),
]
