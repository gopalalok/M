from django.shortcuts import render,redirect
from django.views import  View
from shop.models import Product,Customer
import uuid
from django.utils import timezone
# Create your views here.

class OrderView(View):
    def get(self , request):
        data = {}
        data['all_customer'] = Customer.get_all_customer()
        return render(request , 'shop/order.html',data)

        