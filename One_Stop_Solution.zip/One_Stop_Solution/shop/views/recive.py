from django.shortcuts import render,redirect
from django.views import  View
from shop.models import Product,Customer
import uuid
from django.utils import timezone
# Create your views here.

class ReciveView(View):
    def get(self , request):
        data = {}
        transactionid = request.session.get('transactionid')
        if(transactionid):
            data['order'] = Customer.get_customer_order(transactionid)
            return render(request , 'shop/recive.html',data)
        return redirect('home')

        