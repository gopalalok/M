from django.shortcuts import render,redirect
from django.views import  View
from shop.models import Product,Customer,State
import uuid
from django.utils import timezone
# Create your views here.

class Customer_OrderView(View):
    def get(self , request, id):
        data = {}
        data['all_state'] = State.get_all_state()
        data['all_product'] = Product.get_all_product()
        data['values'] = Customer.objects.get(id=id)
        return render(request , 'shop/customer_order.html',data)

        