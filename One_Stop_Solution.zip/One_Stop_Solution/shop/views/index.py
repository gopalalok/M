from django.shortcuts import render,redirect
from django.views import  View
from shop.models import Product,Customer,State
import uuid
import json
from django.http import HttpResponseRedirect
from django.urls import reverse
from django.utils import timezone
# Create your views here.

class IndexView(View):
    def get(self , request):
        all_product = Product.get_all_product()
        all_state = State.get_all_state()
        return render(request , 'shop/index.html',{'all_product':all_product,'all_state':all_state})

    def post(self , request):
        
        fullname = request.POST.get('fullname')
        item = request.POST.get('item')
        quantity = request.POST.get('quantity')
        mobilenumber = request.POST.get('mobilenumber')
        address = request.POST.get('address')
        pincode = request.POST.get('pincode')
        landmark = request.POST.get('landmark')
        city = request.POST.get('city')
        state = request.POST.get('state')

        # validation
        values = {
            'fullname':fullname,
            'item': item,
            'quantity': quantity,
            'mobilenumber': mobilenumber,
            'address':address,
            'pincode':pincode,
            'landmark':landmark,
            'city':city,
            'state':state
        }
        print(state)
        print(item)
        
        error_message = None
        if(not fullname):
            error_message = "Please enter your name !!!"
        elif(not item):
            error_message = "Select item Required !!!"
        elif(not quantity):
            error_message = "Please enter quantity !!!"
        elif(not mobilenumber):
            error_message = "Please enter mobilenumber !!!"
        elif(len(str(mobilenumber))<10):
            error_message = "Please enter a valid mobilenumber !!!"
        elif(not pincode):
            error_message = "Please enter pincode !!!"
        elif(len(str(pincode))<6):
            error_message = "Please enter a valid pincode !!!"
        elif(not address):
            error_message = "Please enter address !!!"
        elif(not landmark):
            error_message = "Please enter landmark !!!"
        elif(not city):
            error_message = "Please enter your city !!!"
        elif(not state):
            error_message = "Select state Required !!!"

        
        transactionid = uuid.uuid1().hex
        if not error_message:
            data = {}
            all_state = State.get_all_state()
            state_obj = State.objects.get(pk=state)
            all_product = Product.get_all_product()
            product = Product.objects.get(pk=item)
            amount = (int(quantity)/1000)*product.price
            customer = Customer(
                            transactionid = transactionid,
                            fullname=fullname,
                            item = Product(id = item),
                            quantity = quantity,
                            amount = amount,
                            mobilenumber=mobilenumber,
                            address = address,
                            landmark = landmark,
                            city = city,
                            state = State(id = state),
                            pincode=pincode)
            customer.save()
            request.session['message'] = "Your order is placed"
            request.session['transactionid'] = transactionid
            
            return redirect('recive')
            
            
            
        else:
            all_state = State.get_all_state()
            all_product = Product.get_all_product()
            data = {
                'error': error_message,
                'values': values,
                'all_product':all_product,
                'all_state':all_state
            }
            return render(request, 'shop/index.html', data)
